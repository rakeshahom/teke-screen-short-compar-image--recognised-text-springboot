package com.AILocator.AILocator.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.AILocator.AILocator.Model.Login;
import com.AILocator.AILocator.Repository.LoginRepository;

public class CustomUserDetailsService implements UserDetailsService {
	@Autowired
	private LoginRepository loginRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		try {
			Login login = loginRepository.findUserByUsername(username);
			if (login != null) {
				return new CustomUserDetails(login);
			} else {
				throw new UsernameNotFoundException("user not Found...");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

}
