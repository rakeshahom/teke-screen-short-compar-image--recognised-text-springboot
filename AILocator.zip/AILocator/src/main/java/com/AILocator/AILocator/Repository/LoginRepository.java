package com.AILocator.AILocator.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AILocator.AILocator.Model.Login;

@Repository
public interface LoginRepository extends JpaRepository<Login, Integer>{

	
	public Login findUserByUsername(String username);

}
