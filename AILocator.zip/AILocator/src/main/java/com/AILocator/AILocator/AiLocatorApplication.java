package com.AILocator.AILocator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiLocatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiLocatorApplication.class, args);
		
	}

}
