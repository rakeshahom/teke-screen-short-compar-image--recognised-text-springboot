package com.AILocator.AILocator.Model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.Data;

@Data
@Entity

public class Login {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
//	@NotEmpty(message = "Enter name.")
	private String name;
	
//	@NotEmpty(message = "Enter user name.")
	private String username;
	
//	@Email(message = "Enter a valid email.")
	private String email;
	
//	@NotEmpty(message = "Enter password.")
	private String password;
	
//	@NotEmpty(message = "Enter address.")
	private String address;
	
	private String gender;
	private boolean status;
	
//	@NotEmpty(message = "Select Date of birth")
	private String dob;
	
	@ManyToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinTable(name = "user_role", joinColumns = {
			@JoinColumn(name = "USER_ID", referencedColumnName = "ID") }, inverseJoinColumns = {
					@JoinColumn(name = "ROLE_ID", referencedColumnName = "ID") })
	private List<Roles> roles;

	public Login() {
		super();
	}

	public Login(int id, String name, String username, String email, String password, String address, String gender,
			boolean status, String dob, List<Roles> roles) {
		super();
		this.id = id;
		this.name = name;
		this.username = username;
		this.email = email;
		this.password = password;
		this.address = address;
		this.gender = gender;
		this.status = status;
		this.dob = dob;
		this.roles = roles;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public List<Roles> getRoles() {
		return roles;
	}

	public void setRoles(List<Roles> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "Login [id=" + id + ", name=" + name + ", username=" + username + ", email=" + email + ", password="
				+ password + ", address=" + address + ", gender=" + gender + ", status=" + status + ", dob=" + dob
				+ ", roles=" + roles + "]";
	}

}
