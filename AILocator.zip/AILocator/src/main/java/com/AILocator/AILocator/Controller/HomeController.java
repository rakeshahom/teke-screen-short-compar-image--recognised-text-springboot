package com.AILocator.AILocator.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
//@RequestMapping("/user")
public class HomeController {

	
	@GetMapping("/home")
	public String home() {

		return "index";
	}
	@GetMapping("/table")
	public String table() {

		return "tables";
	}
	@GetMapping("/form")
	public String form() {

		return "forms";
	}
	@GetMapping("/root")
	public String root_location() {

		return "root_map";
	}
}
