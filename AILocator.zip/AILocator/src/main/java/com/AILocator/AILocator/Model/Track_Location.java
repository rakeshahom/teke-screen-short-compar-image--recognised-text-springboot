package com.AILocator.AILocator.Model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Track_Location {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="track_id")
	private int id;
	private double latitude;
	private double longitude;
	private Date cu_time;
	
	@ManyToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	@JoinTable(name = "user_track", joinColumns = {
			@JoinColumn(name = "track_Id", referencedColumnName = "track_id") }, inverseJoinColumns = {
					@JoinColumn(name = "user_Id", referencedColumnName = "id") })
	List<Login> user;

	public Track_Location() {
		super();
	}

	public Track_Location(int id, double latitude, double longitude, Date cu_time, List<Login> user) {
		super();
		this.id = id;
		this.latitude = latitude;
		this.longitude = longitude;
		this.cu_time = cu_time;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public Date getCu_time() {
		return cu_time;
	}

	public void setCu_time(Date cu_time) {
		this.cu_time = cu_time;
	}

	public List<Login> getUser() {
		return user;
	}

	public void setUser(List<Login> user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Track_Location [id=" + id + ", latitude=" + latitude + ", longitude=" + longitude + ", cu_time="
				+ cu_time + ", user=" + user + "]";
	}

	
	
}
